import {useState} from 'react';
import React from 'react';
import RandName from './components/RandName.jsx';


export function App() {
  return ( 
    <RandName />  
  );
}
